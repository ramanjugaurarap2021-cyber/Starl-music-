# Starl Music

Android build of Starl using the supplied `Starl4.html` interface inside Android WebView. The HTML/CSS presentation is kept intact; Android provides the native device audio library scanner.

## Included

- Existing Starl HTML interface and interactions, preserved as the app UI.
- Android MediaStore audio scan (no manual file picking required on Android).
- Runtime audio permission request for Android 13+ and older Android versions.
- Reads title, artist, album, track number, duration, file path, date added/modified, and genre when the device exposes it.
- Rescan on opening **Local music**; newly discovered tracks are added without duplicating existing tracks.
- Existing Songs / Albums / Artists grouping and sorting.
- Existing Liked songs plus Chill vibes / Gym mix / Focus flow smart playlists, populated from local genre metadata.
- Existing browser Add files / Add folder controls remain available as fallback.

## Build APK with GitHub

1. Create a new GitHub repository named `StarlMusic`.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open **Actions** and run **Build Starl APK**, or push to the `main` branch.
4. Open the completed workflow run and download the `Starl-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone.

## Notes

- The app asks for audio permission the first time Local music is opened.
- Genre smart playlists depend on genre tags being present in the device's media database. Tracks without genre metadata still appear in Songs, Albums, and Artists.
- This first build keeps the existing HTML audio player and UI. Background playback controls / notification media session are a separate native integration and are not claimed as implemented here.
