# Starl Music

Android WebView shell for the existing Starl music interface, with native Android local-audio scanning and the supplied Starl launcher icon.

## Build on GitHub Actions

1. Upload the contents of this folder to the repository root.
2. Open **Actions → Build Starl APK → Run workflow**.
3. Download the `Starl-Music-APK` artifact after a successful run.

The workflow no longer uses `gradle/actions/setup-gradle` to provision Gradle, which was the step returning HTTP 504. It downloads the Gradle 8.9 distribution directly with retry handling. It also downloads the official Gradle 8.9 wrapper JAR at build time; the wrapper scripts and wrapper properties are included in this project.

The build has not been executed in this environment. A successful GitHub Actions run is still required to confirm compilation.
