package com.starl.music

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val audioPermissionRequest = 4102

    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean =
        checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowContentAccess = true
            settings.allowFileAccess = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (uri.scheme == "content" && uri.authority == MediaStore.AUTHORITY) {
                        return try {
                            val stream = contentResolver.openInputStream(uri) ?: return null
                            val mime = contentResolver.getType(uri) ?: "audio/*"
                            WebResourceResponse(mime, null, stream)
                        } catch (_: Exception) { null }
                    }
                    return super.shouldInterceptRequest(view, request)
                }
            }
            addJavascriptInterface(StarlBridge(), "StarlNative")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class StarlBridge {
        @JavascriptInterface fun hasAudioPermission(): Boolean = this@MainActivity.hasAudioPermission()

        @JavascriptInterface fun requestAudioPermission() {
            runOnUiThread {
                if (hasAudioPermission()) {
                    web.evaluateJavascript("window.onStarlPermissionResult && window.onStarlPermissionResult(true)", null)
                } else {
                    requestPermissions(arrayOf(audioPermission()), audioPermissionRequest)
                }
            }
        }

        @JavascriptInterface fun scanAudio(): String {
            if (!hasAudioPermission()) return "[]"
            val result = JSONArray()
            val audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.TRACK,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.DATE_MODIFIED,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.RELATIVE_PATH,
                MediaStore.Audio.Media.SIZE
            )
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
            val args = arrayOf("30000")
            val genres = loadGenres()
            val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            contentResolver.query(audioUri, projection, selection, args, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val trackCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val modifiedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val pathCol = c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val itemUri = ContentUris.withAppendedId(audioUri, id)
                    val item = JSONObject()
                    item.put("id", id)
                    item.put("title", c.getString(titleCol) ?: c.getString(nameCol) ?: "Unknown title")
                    item.put("artist", c.getString(artistCol)?.takeUnless { it == "<unknown>" }.orEmpty().ifBlank { "Unknown Artist" })
                    item.put("album", c.getString(albumCol)?.takeUnless { it == "<unknown>" } ?: JSONObject.NULL)
                    item.put("duration", c.getLong(durationCol))
                    item.put("track", c.getInt(trackCol) % 1000)
                    item.put("dateAdded", c.getLong(addedCol))
                    item.put("dateModified", c.getLong(modifiedCol))
                    item.put("fileName", c.getString(nameCol) ?: "")
                    item.put("path", if (pathCol >= 0) c.getString(pathCol).orEmpty() else "")
                    item.put("size", c.getLong(sizeCol))
                    item.put("genre", genres[id] ?: JSONObject.NULL)
                    item.put("url", itemUri.toString())
                    result.put(item)
                }
            }
            return result.toString()
        }

        private fun loadGenres(): Map<Long, String> {
            val result = mutableMapOf<Long, String>()
            try {
                val genreUri = MediaStore.Audio.Genres.getContentUri("external")
                contentResolver.query(genreUri, arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME), null, null, null)?.use { genres ->
                    val idCol = genres.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
                    val nameCol = genres.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
                    while (genres.moveToNext()) {
                        val genreId = genres.getLong(idCol)
                        val name = genres.getString(nameCol) ?: continue
                        val members = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                        contentResolver.query(members, arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID), null, null, null)?.use { songs ->
                            val audioIdCol = songs.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                            while (songs.moveToNext()) result[songs.getLong(audioIdCol)] = name
                        }
                    }
                }
            } catch (_: Exception) { }
            return result
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            web.evaluateJavascript("window.onStarlPermissionResult && window.onStarlPermissionResult($granted)", null)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        web.evaluateJavascript("window.starlHandleBack && window.starlHandleBack()", null)
        if (Build.VERSION.SDK_INT < 33) super.onBackPressed()
    }
}
